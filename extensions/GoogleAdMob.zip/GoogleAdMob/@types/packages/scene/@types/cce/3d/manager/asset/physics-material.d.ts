import EditComponentAsset from './edit-component-asset';
declare class EditPhysicsMaterial extends EditComponentAsset {
}
declare const _default: EditPhysicsMaterial;
export default _default;
//# sourceMappingURL=physics-material.d.ts.map