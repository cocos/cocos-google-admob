import EngineUtils from './3d';
export default EngineUtils;
//# sourceMappingURL=index.d.ts.map