export enum TestUnitId {
    BannerAd = "ca-app-pub-3940256099942544/6300978111",
    InterstitialAd = "ca-app-pub-3940256099942544/3419835294",
    AppOpenAd = "ca-app-pub-3940256099942544/3419835294",
    RewardedAd = "ca-app-pub-3940256099942544/5224354917",
    NativeAd = "ca-app-pub-3940256099942544/2247696110",
    RewardedInterstitialAd = "ca-app-pub-3940256099942544/5354046379",
}