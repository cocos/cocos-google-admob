# Native Templates Android

This repository contains an Android Studio module with two views you can use
with Native ads in your applications.

See https://developers.google.com/admob/android/native/templates for
documentation on using these templates.
