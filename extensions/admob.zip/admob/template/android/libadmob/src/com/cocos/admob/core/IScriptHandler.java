package com.cocos.admob.core;

public interface IScriptHandler {
    void onMessage(Object arg);
}
