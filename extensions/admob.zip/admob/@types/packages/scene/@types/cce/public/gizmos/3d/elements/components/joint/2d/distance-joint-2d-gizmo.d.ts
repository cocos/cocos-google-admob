import Joint2DGizmo from './joint-2d-gizmo';
declare class DistanceJoint2DGizmo extends Joint2DGizmo {
    private _lineController;
    createController(): void;
    onHide(): void;
    updateAnchorControllerData(): void;
}
export default DistanceJoint2DGizmo;
//# sourceMappingURL=distance-joint-2d-gizmo.d.ts.map