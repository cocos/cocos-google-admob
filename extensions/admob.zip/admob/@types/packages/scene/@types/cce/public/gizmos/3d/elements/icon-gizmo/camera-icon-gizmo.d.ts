import IconGizmoBase from './icon-gizmo-base';
declare class CameraIconGizmo extends IconGizmoBase {
    createController(): void;
}
export default CameraIconGizmo;
//# sourceMappingURL=camera-icon-gizmo.d.ts.map