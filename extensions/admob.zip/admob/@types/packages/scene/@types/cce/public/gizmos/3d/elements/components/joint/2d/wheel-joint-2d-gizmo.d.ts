import Joint2DGizmo from './joint-2d-gizmo';
declare class WheelJoint2DGizmo extends Joint2DGizmo {
}
export default WheelJoint2DGizmo;
//# sourceMappingURL=wheel-joint-2d-gizmo.d.ts.map