import { SceneUndoManager } from './scene';
declare const prefabUndoManager: SceneUndoManager;
export default prefabUndoManager;
//# sourceMappingURL=prefab.d.ts.map